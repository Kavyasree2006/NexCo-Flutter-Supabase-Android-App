package com.example.nexco

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
