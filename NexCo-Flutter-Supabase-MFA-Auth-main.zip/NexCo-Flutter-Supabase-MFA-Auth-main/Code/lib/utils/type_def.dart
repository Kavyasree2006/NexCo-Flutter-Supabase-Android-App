typedef ValidatorCallback = String? Function(String? arg);
typedef InputCallback = void Function(String? name);
typedef DeleteCallback = void Function(int id);
